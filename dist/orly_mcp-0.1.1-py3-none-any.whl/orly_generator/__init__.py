# This file makes slack a Python package
# Contains only the core image generation functionality for MCP server
